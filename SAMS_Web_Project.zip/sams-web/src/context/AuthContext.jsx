import { createContext, useContext, useState, useCallback } from 'react'

const AuthContext = createContext(null)

/* ─── Hardcoded credentials ─────────────────────────────────────────────── */
const CREDENTIALS = {
  admin:   { password: 'Admin@123',   role: 'principal', name: 'Dr. Rajesh Kumar',   id: 'P001' },
  teacher: { password: 'Teacher@123', role: 'teacher',   name: 'Priya Sharma',       id: 'T001' },
}

const SESSION_KEY = 'sams_session'

function loadSession() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY)) } catch { return null }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(loadSession)

  const login = useCallback((username, password) => {
    const cred = CREDENTIALS[username.toLowerCase()]
    if (!cred || cred.password !== password) return { ok: false, error: 'Invalid username or password.' }

    const session = { username, role: cred.role, name: cred.name, id: cred.id }
    localStorage.setItem(SESSION_KEY, JSON.stringify(session))
    setUser(session)
    return { ok: true, role: cred.role }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(SESSION_KEY)
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoggedIn: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
