const pool = require('../config/mysqlDb');
const { getUnifiedNotifications } = require('../utils/notificationHelper');

// Helper for ultra-safe JSON parsing
const safeParse = (data) => {
  if (!data) return [];
  if (typeof data !== 'string') return Array.isArray(data) ? data : [];
  try {
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
};

const lmsIntelligenceController = {
  getTeacherDashboard: async (req, res) => {
    const result = {
      syllabus: { completed: 0, total: 0, percentage: 0 },
      lo: { approaching: 0, meeting: 0, exceeding: 0, total: 0 },
      not_done_students: [], // Execution Alerts
      overall_score: 0,
      performance: { syllabus: 0, lo: 0, observation: 0 },
      warnings: []
    };

    try {
      const teacherId = req.user?.id; // Use User ID directly for isolation
      if (!teacherId) return res.json({ success: true, data: result });

      const [rows] = await pool.execute(`
        SELECT 
          s.id, s.topic, s.week, s.month, s.is_completed, s.status, s.students_data,
          s.periods, s.periods_needed, s.class_understanding_level, s.notebook_checked,
          s.class_id, s.section_id, s.subject_id,
          ac.class_number, asec.name as section_name, sub.name as subject_name
        FROM syllabus s
        LEFT JOIN academic_classes ac ON s.class_id = ac.id
        LEFT JOIN acad_sections asec ON s.section_id = asec.id
        LEFT JOIN subjects sub ON s.subject_id = sub.id
        WHERE s.teacher_id = ?
      `, [teacherId]);

      // Get class sizes for fallback counting
      const [classCounts] = await pool.execute('SELECT class_id, COUNT(*) as count FROM students GROUP BY class_id');
      const classSizes = classCounts.reduce((acc, c) => ({ ...acc, [c.class_id]: c.count }), {});

      rows.forEach(row => {
        result.syllabus.total++;
        const isTopicDone = row.is_completed === 1 || row.status === 'completed';
        if (isTopicDone) result.syllabus.completed++;

        const students = safeParse(row.students_data);
        const classLvl = (row.class_understanding_level || '').toLowerCase();
        
        if (isTopicDone && classLvl && classLvl !== '-' && classLvl !== 'awaiting status') {
          if (classLvl.includes('approach')) result.lo.approaching++;
          else if (classLvl.includes('exceed')) result.lo.exceeding++;
          else if (classLvl.includes('meet')) result.lo.meeting++;
          result.lo.total++;
        }

        // 2. Execution Alerts (Individual Student Level)
        students.forEach(s => {
          const isNotDone = s.homework === false || s.homework_status === 'PENDING';
          if (isNotDone) {
            result.not_done_students.push({
              id: row.id, topic: row.topic, week: row.week,
              class_id: row.class_id, section_id: row.section_id, subject_id: row.subject_id,
              class: `${row.class_number || 'N/A'}-${row.section_name || 'N/A'}`, subject: row.subject_name,
              status: 'Homework Pending', name: s.name || 'N/A'
            });
          }
        });

        if (row.notebook_checked === 'No' && isTopicDone) {
           result.not_done_students.push({
             id: row.id, topic: row.topic, week: row.week,
             class_id: row.class_id, section_id: row.section_id, subject_id: row.subject_id,
             class: `${row.class_number || 'N/A'}-${row.section_name || 'N/A'}`, subject: row.subject_name,
             status: 'Notebook Issue', name: 'Class Total'
           });
        }
      });

      result.syllabus.percentage = result.syllabus.total > 0 
        ? Math.round((result.syllabus.completed / result.syllabus.total) * 100) : 0;

      const loTotal = result.lo.total || 0;
      const loScore = loTotal > 0 
        ? ((result.lo.exceeding * 100) + (result.lo.meeting * 80) + (result.lo.approaching * 60)) / loTotal : 0;

      const [obs] = await pool.execute(`
        SELECT AVG(((content_mastery + pedagogy + student_engagement + communication + assessment) / 50) * 100) AS avg_obs
        FROM class_observations WHERE teacher_id = ?
      `, [teacherId]);
      const obsScore = obs[0]?.avg_obs || 0;

      result.overall_score = parseFloat(((result.syllabus.percentage * 0.5) + (loScore * 0.3) + (obsScore * 0.2)).toFixed(1));
      result.performance = { syllabus: result.syllabus.percentage, lo: Math.round(loScore), observation: Math.round(obsScore) };
      
      result.not_done_students = result.not_done_students.slice(0, 15);
      res.json({ success: true, data: { ...result, all_rows: rows } });
    } catch (error) {
      console.error("DASHBOARD ERROR:", error);
      res.status(500).json({ success: false, message: error.message });
    }
  },

  getLOIntelligence: async (req, res) => {
    try {
      const teacherId = req.user?.id;
      const [rows] = await pool.execute(`
        SELECT s.students_data, topic, sub.name as subjectName
        FROM syllabus s JOIN subjects sub ON s.subject_id = sub.id
        WHERE s.teacher_id = ? AND (s.is_completed = 1 OR s.status = 'completed')
      `, [teacherId]);

      const stats = { approaching: 0, meeting: 0, exceeding: 0, total: 0 };
      const topics = rows.map(r => {
        const students = safeParse(r.students_data);
        const tstats = { approaching: 0, meeting: 0, exceeding: 0 };
        students.forEach(s => {
          const slvl = (s.learning_status || 'meeting').toLowerCase();
          if (slvl.includes('approach')) { tstats.approaching++; stats.approaching++; }
          else if (slvl.includes('exceed')) { tstats.exceeding++; stats.exceeding++; }
          else { tstats.meeting++; stats.meeting++; }
          stats.total++;
        });
        return { topic: r.topic, subject: r.subjectName, ...tstats };
      });
      res.json({ success: true, data: { distribution: stats, topics } });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
  },

  getMicroIntelligence: async (req, res) => {
    try {
      const teacherId = req.user?.id;
      const [rows] = await pool.execute(`
        SELECT s.*, ac.name as class_name, sub.name as subject_name
        FROM syllabus s LEFT JOIN academic_classes ac ON s.class_id = ac.id LEFT JOIN subjects sub ON s.subject_id = sub.id
        WHERE s.teacher_id = ?
      `, [teacherId]);

      const data = rows.map(row => {
        const students = safeParse(row.students_data);
        const notDone = students.filter(s => s.homework === false || s.homework_status === 'PENDING');
        const rate = students.length > 0 ? Math.round(((students.length - notDone.length) / students.length) * 100) : 0;
        return { id: row.id, topic: row.topic, class: row.class_name, subject: row.subject_name, week: row.week, completion_rate: rate, not_done_students: notDone.length, risk_level: rate < 50 ? 'HIGH' : rate < 80 ? 'MEDIUM' : 'LOW' };
      });
      res.json({ success: true, data });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
  },

  getAnalytics: async (req, res) => lmsIntelligenceController.getTeacherDashboard(req, res),
  getNotifications: async (req, res) => {
    const notifications = await getUnifiedNotifications(req.user.id, req.user.role);
    res.json({ success: true, data: notifications });
  },
  getAdminDashboard: async (req, res) => {
    const [stats] = await pool.execute('SELECT COUNT(*) as total_teachers FROM teachers WHERE status = "active"');
    res.json({ success: true, data: { totalTeachers: stats[0]?.total_teachers || 0 } });
  },
  runIntelligenceEngine: async (req, res) => res.json({ success: true, message: 'Engine running in background' })
};

module.exports = lmsIntelligenceController;
